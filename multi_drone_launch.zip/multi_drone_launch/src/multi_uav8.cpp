#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>
#include <vector>
#include <tuple>

mavros_msgs::State current_states[8];
void state_cb(const mavros_msgs::State::ConstPtr& msg, int uav_id){
    current_states[uav_id] = *msg;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "multi_uav");
    ros::NodeHandle nh;

    std::vector<ros::Subscriber> state_subs;
    std::vector<ros::Publisher> local_pos_pubs;
    std::vector<ros::ServiceClient> arming_clients;
    std::vector<ros::ServiceClient> set_mode_clients;

    for (int i = 0; i < 8; ++i) {
        std::string ns = "uav" + std::to_string(i);
        state_subs.push_back(nh.subscribe<mavros_msgs::State>(ns + "/mavros/state", 10, boost::bind(state_cb, _1, i)));
        local_pos_pubs.push_back(nh.advertise<geometry_msgs::PoseStamped>(ns + "/mavros/setpoint_position/local", 10));
        arming_clients.push_back(nh.serviceClient<mavros_msgs::CommandBool>(ns + "/mavros/cmd/arming"));
        set_mode_clients.push_back(nh.serviceClient<mavros_msgs::SetMode>(ns + "/mavros/set_mode"));
    }

    ros::Rate rate(20.0);

    // Wait for FCU connection
    for (int i = 0; i < 8; ++i) {
        while(ros::ok() && !current_states[i].connected){
            ROS_INFO("Waiting for FCU connection for UAV%d", i);
            ros::spinOnce();
            rate.sleep();
        }
    }

    std::vector<geometry_msgs::PoseStamped> poses(8);
    for (int i = 0; i < 8; ++i) {
        poses[i].pose.position.x = 0;
        poses[i].pose.position.y = 0;
        poses[i].pose.position.z = 2;
    }

    // Send a few setpoints before starting
    for (int i = 0; i < 100; ++i) {
        for (int j = 0; j < 8; ++j) {
            local_pos_pubs[j].publish(poses[j]);
        }
        ros::spinOnce();
        rate.sleep();
    }

    std::vector<mavros_msgs::SetMode> offb_set_modes(8);
    std::vector<mavros_msgs::CommandBool> arm_cmds(8);

    for (int i = 0; i < 8; ++i) {
        offb_set_modes[i].request.custom_mode = "OFFBOARD";
        arm_cmds[i].request.value = true;
    }

    ros::Time last_request = ros::Time::now();

    std::vector<std::vector<std::tuple<float, float, float>>> waypoints = {
        {{-6.0, 10.0, 5.0}, {-6.0, 0.0, 5.0}},   // UAV 0 waypoints
        {{-4.0, 10.0, 5.0}, {-4.0, 0.0, 5.0}},   // UAV 1 waypoints
        {{-2.0, 10.0, 5.0}, {-2.0, 0.0, 5.0}},   // UAV 2 waypoints
        {{0.0, 10.0, 5.0}, {0.0, 0.0, 5.0}},   // UAV 3 waypoints
        {{2.0, 10.0, 5.0}, {2.0, 0.0, 5.0}},   // UAV 4 waypoints
        {{4.0, 10.0, 5.0}, {4.0, 0.0, 5.0}},  // UAV 5 waypoints
        {{6.0, 10.0, 5.0}, {6.0, 0.0, 5.0}},  // UAV 6 waypoints
        {{8.0, 10.0, 5.0}, {8.0, 0.0, 5.0}}   // UAV 7 waypoints
    };

    while (ros::ok()) {
        for (int i = 0; i < 8; ++i) {
            if (current_states[i].mode != "OFFBOARD" &&
                (ros::Time::now() - last_request > ros::Duration(5.0))){
                if (set_mode_clients[i].call(offb_set_modes[i]) &&
                    offb_set_modes[i].response.mode_sent){
                    ROS_INFO("Offboard enabled for UAV%d", i);
                } else {
                    ROS_WARN("Failed to set Offboard mode for UAV%d", i);
                }
                last_request = ros::Time::now();
            } else {
                if (!current_states[i].armed &&
                    (ros::Time::now() - last_request > ros::Duration(5.0))){
                    if (arming_clients[i].call(arm_cmds[i]) &&
                        arm_cmds[i].response.success){
                        ROS_INFO("Vehicle armed for UAV%d", i);
                    } else {
                        ROS_WARN("Failed to arm UAV%d", i);
                    }
                    last_request = ros::Time::now();
                }
            }

            // Send waypoints
            for (auto& wp : waypoints[i]) {
                poses[i].pose.position.x = std::get<0>(wp);
                poses[i].pose.position.y = std::get<1>(wp);
                poses[i].pose.position.z = std::get<2>(wp);

                for (int j = 0; j < 100; ++j) {
                    local_pos_pubs[i].publish(poses[i]);
                    ros::spinOnce();
                    rate.sleep();
                }
            }
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
