#include <ros/ros.h>
#include <vector>
#include <tuple>
#include <string>
#include <sstream>
#include <sstream>
#include <geometry_msgs/PoseStamped.h>

// #include "point_planner.h"

// 解析路径点序列为字符串
std::string serialize_waypoints(const std::vector<std::tuple<float, float, float>>& waypoints) {
    std::stringstream ss;
    for (size_t i = 0; i < waypoints.size(); ++i) {
        if (i > 0) ss << ";";
        ss << std::get<0>(waypoints[i]) << "," << std::get<1>(waypoints[i]) << "," << std::get<2>(waypoints[i]);
    }
    return ss.str();
}

std::vector<std::tuple<float, float, float>> simple_planner(std::tuple<float, float, float> start_pos, std::tuple<float, float, float> goal_pos) {
    std::vector<std::tuple<float, float, float>> waypoints;

    if(abs(std::get<0>(start_pos) - std::get<0>(goal_pos)) <= abs(std::get<1>(start_pos) - std::get<1>(goal_pos))) {
        waypoints.emplace_back(std::get<0>(start_pos), std::get<1>(goal_pos), std::get<2>(start_pos));
        waypoints.emplace_back(std::get<0>(goal_pos), std::get<1>(goal_pos), std::get<2>(start_pos));
        waypoints.emplace_back(std::get<0>(goal_pos), std::get<1>(goal_pos), std::get<2>(goal_pos));
    }
    else{
        waypoints.emplace_back(std::get<0>(goal_pos), std::get<1>(start_pos), std::get<2>(start_pos));
        waypoints.emplace_back(std::get<0>(goal_pos), std::get<1>(goal_pos), std::get<2>(start_pos));
        waypoints.emplace_back(std::get<0>(goal_pos), std::get<1>(goal_pos), std::get<2>(goal_pos));
    }
    return waypoints;
}

std::vector<std::tuple<float, float, float>> get_three_points(std::tuple<float, float, float> central) {
    std::vector<std::tuple<float, float, float>> waypoints;

    waypoints.emplace_back(std::get<0>(central)-1, std::get<1>(central)+1, std::get<2>(central));
    waypoints.emplace_back(std::get<0>(central), std::get<1>(central)-1, std::get<2>(central));
    waypoints.emplace_back(std::get<0>(central)+1, std::get<1>(central)+1, std::get<2>(central));

    
    return waypoints;
}

// 位置回调函数
void position_cb(const geometry_msgs::PoseStamped::ConstPtr& msg, geometry_msgs::PoseStamped* position) {
    *position = *msg;
}

bool all_uavs_at_last_waypoint(const std::vector<std::tuple<float, float, float>>& last_waypoints,
                               const std::vector<geometry_msgs::PoseStamped>& current_positions, float threshold = 0.5) {
    for (size_t i = 0; i < last_waypoints.size(); ++i) {
        float dx = std::get<0>(last_waypoints[i]) - current_positions[i].pose.position.x;
        float dy = std::get<1>(last_waypoints[i]) - current_positions[i].pose.position.y;
        float dz = std::get<2>(last_waypoints[i]) - current_positions[i].pose.position.z;
        if (std::sqrt(dx*dx + dy*dy + dz*dz) > threshold) {
            return false;
        }
    }
    return true;
}





int main(int argc, char **argv) {
    ros::init(argc, argv, "uavs 3--5 upload_waypoints");
    ros::NodeHandle nh;

    int state = 1;  // 1 表示在区域搜索中， 2 表示在前往给定的目标点中

    // 定义路径点序列
    std::vector<std::tuple<float, float, float>> uav3_waypoints = {
        {0.0, 0.0, 5.0}, {0.0, 10.0, 5.0}
    };
    std::vector<std::tuple<float, float, float>> uav4_waypoints = {
        {2.0, 0.0, 5.0}, {2.0, 10.0, 5.0}
    };
    std::vector<std::tuple<float, float, float>> uav5_waypoints = {
        {4.0, 0.0, 5.0}, {4.0, 10.0, 5.0}
    };

    // 添加更多的无人机路径点
    // std::vector<std::tuple<float, float, float>> uav2_waypoints = ...

    // 将路径点序列上传到参数服务器
    nh.setParam("/uav3/waypoints", serialize_waypoints({uav3_waypoints[0]}));
    nh.setParam("/uav4/waypoints", serialize_waypoints({uav4_waypoints[0]}));
    nh.setParam("/uav5/waypoints", serialize_waypoints({uav5_waypoints[0]}));
    // nh.setParam("/uav0/waypoints", serialize_waypoints(uav0_waypoints));
    // nh.setParam("/uav1/waypoints", serialize_waypoints(uav1_waypoints));
    // nh.setParam("/uav2/waypoints", serialize_waypoints(uav2_waypoints));
    // nh.setParam("/uav3/waypoints", serialize_waypoints(uav3_waypoints));
    // nh.setParam("/uav4/waypoints", serialize_waypoints(uav4_waypoints));
    // nh.setParam("/uav5/waypoints", serialize_waypoints(uav5_waypoints));
    // nh.setParam("/uav6/waypoints", serialize_waypoints(uav6_waypoints));
    // nh.setParam("/uav7/waypoints", serialize_waypoints(uav7_waypoints));
    // nh.setParam("/uav2/waypoints", serialize_waypoints(uav2_waypoints));
    // 继续添加其他 UAV 的路径点序列


    ROS_INFO("Waypoints uploaded to parameter server");


// 订阅每个无人机的位置
    std::vector<geometry_msgs::PoseStamped> current_positions(8);
    std::vector<ros::Subscriber> position_subs;

    for (int i = 0; i < 3; ++i) {
        std::string topic = "/uav" + std::to_string(i+3) + "/mavros/local_position/pose";
        position_subs.push_back(nh.subscribe<geometry_msgs::PoseStamped>(
            topic, 10, boost::bind(position_cb, _1, &current_positions[i])
        ));
    }

    // ros::Publisher target_pub = nh.advertise<geometry_msgs::PoseStamped>("/uav0/mavros/setpoint_position/local", 10);
    size_t target_index = 0;
    ros::Rate rate(10.0);

    while (ros::ok()) {
        ros::spinOnce();
        
        if(state == 1 && target_index < uav3_waypoints.size()){
                // 检查所有无人机是否到达最后一个点
            if (all_uavs_at_last_waypoint({uav3_waypoints[target_index], uav4_waypoints[target_index], uav5_waypoints[target_index]}, 
                                            current_positions)) {
                ROS_INFO("Uavs3--5 Reached sousuo waypoint %zu", target_index);
                target_index++;  // 更新到下一个目标点
            }
            else{
                continue;
            }

            if (target_index < uav3_waypoints.size()) {
                // 发送下一个目标点
                nh.setParam("/uav3/waypoints", serialize_waypoints({uav3_waypoints[target_index]}));
                nh.setParam("/uav4/waypoints", serialize_waypoints({uav4_waypoints[target_index]}));
                nh.setParam("/uav5/waypoints", serialize_waypoints({uav5_waypoints[target_index]}));
            } 
            else {
                target_index = 0;
                state =  2;
                ROS_INFO("All sousuo waypoints reached!");

                std::vector<std::tuple<float, float, float>> aim_points = get_three_points({0.0, 2.0, 0.0});
                

                std::vector<std::tuple<float, float, float>> new_uav3_waypoints = simple_planner({current_positions[0].pose.position.x,current_positions[0].pose.position.y,current_positions[0].pose.position.z},aim_points[0]);
                std::vector<std::tuple<float, float, float>> new_uav4_waypoints = simple_planner({current_positions[1].pose.position.x,current_positions[1].pose.position.y,current_positions[1].pose.position.z},aim_points[1]);
                std::vector<std::tuple<float, float, float>> new_uav5_waypoints = simple_planner({current_positions[2].pose.position.x,current_positions[2].pose.position.y,current_positions[2].pose.position.z},aim_points[2]);

                // // 定义新的路径点序列
                // std::vector<std::tuple<float, float, float>> new_uav0_waypoints = {
                //     {-6.0, 5.0, 5.0}, {-5.0, 5.0, 5.0}, {-5.0, 5.0, 0.0}
                // };
                // std::vector<std::tuple<float, float, float>> new_uav1_waypoints = {
                //     {-4.0, 5.0, 5.0}, {-4.0, 5.0, 5.0}, {-4.0, 5.0, 0.0}
                // };
                // std::vector<std::tuple<float, float, float>> new_uav2_waypoints = {
                //     {-2, 4.0, 5.0}, {-3, 4.0, 5.0}, {-3.0, 4.0, 0.0}
                // };
                // 上传新的路径点到参数服务器
                nh.setParam("/uav3/waypoints", serialize_waypoints(new_uav3_waypoints));
                nh.setParam("/uav4/waypoints", serialize_waypoints(new_uav4_waypoints));
                nh.setParam("/uav5/waypoints", serialize_waypoints(new_uav5_waypoints));

                // 更新本地变量
                uav3_waypoints = new_uav3_waypoints;
                uav4_waypoints = new_uav4_waypoints;
                uav5_waypoints = new_uav5_waypoints;

            }

        }
        


        if(state == 2 && target_index < uav3_waypoints.size()){
            // ROS_INFO("state = 2");
                // 检查所有无人机是否到达最后一个点
            if (all_uavs_at_last_waypoint({uav3_waypoints[target_index], uav4_waypoints[target_index], uav5_waypoints[target_index]}, 
                                            current_positions)) {
                ROS_INFO("Uavs3--5 Reached jiangluo waypoint %zu", target_index);
                target_index++;  // 更新到下一个目标点
            }
            else{
                continue;
            }

            if (target_index < uav3_waypoints.size()) {
                // 发送下一个目标点
                nh.setParam("/uav3/waypoints", serialize_waypoints({uav3_waypoints[target_index]}));
                nh.setParam("/uav4/waypoints", serialize_waypoints({uav4_waypoints[target_index]}));
                nh.setParam("/uav5/waypoints", serialize_waypoints({uav5_waypoints[target_index]}));
            } 
            else {
                ROS_INFO("All jiangluo waypoints reached!");
                break;
            }

        }
        
        rate.sleep();
    }



    return 0;
}
