#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/CommandBool.h>
#include <mavros_msgs/SetMode.h>

mavros_msgs::State current_state;
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

// 解析路径点序列
std::vector<std::tuple<float, float, float>> parse_waypoints(const std::string &waypoints_str) {
    std::vector<std::tuple<float, float, float>> waypoints;
    std::stringstream ss(waypoints_str);
    std::string item;

    while (std::getline(ss, item, ';')) {
        std::stringstream item_ss(item);
        std::string coord;
        std::vector<float> coords;
        while (std::getline(item_ss, coord, ',')) {
            coords.push_back(std::stof(coord));
        }
        if (coords.size() == 3) {
            waypoints.emplace_back(coords[0], coords[1], coords[2]);
        }
    }
    return waypoints;
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "uav7");
    ros::NodeHandle nh;
    std::string ns = "uav7";
    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>("uav7/mavros/state", 10, state_cb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>("uav7/mavros/setpoint_position/local", 10);
    ros::ServiceClient arming_client = nh.serviceClient<mavros_msgs::CommandBool>("uav7/mavros/cmd/arming");
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>("uav7/mavros/set_mode");

    ros::Rate rate(20.0);

    ROS_INFO("111");
    // Wait for FCU connection
    while(ros::ok() && !current_state.connected){
        ROS_INFO("false");
        ros::spinOnce();
        rate.sleep();
    }

    ROS_INFO("2222");
    geometry_msgs::PoseStamped pose;
    pose.pose.position.x = 0;
    pose.pose.position.y = 0;
    pose.pose.position.z = 2;

    // Send a few setpoints before starting
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(pose);
        ros::spinOnce();
        rate.sleep();
    }

    mavros_msgs::SetMode offb_set_mode;
    offb_set_mode.request.custom_mode = "OFFBOARD";

    mavros_msgs::CommandBool arm_cmd;
    arm_cmd.request.value = true;

    ros::Time last_request = ros::Time::now();

    while(ros::ok()){
        if( current_state.mode != "OFFBOARD" &&
            (ros::Time::now() - last_request > ros::Duration(5.0))){
            if( set_mode_client.call(offb_set_mode) &&
                offb_set_mode.response.mode_sent){
                ROS_INFO("Offboard enabled");
            }
            last_request = ros::Time::now();
        } else {
            if( !current_state.armed &&
                (ros::Time::now() - last_request > ros::Duration(5.0))){
                if( arming_client.call(arm_cmd) &&
                    arm_cmd.response.success){
                    ROS_INFO("Vehicle armed");
                }
                last_request = ros::Time::now();
            }
        }

        // Define waypoints
        // std::vector<std::tuple<float, float, float>> waypoints = {
        //     {8.0, 0.0, 5.0},
        //     {8.0, 10.0, 5.0}
        // };
        std::string waypoints_str;
        std::vector<std::tuple<float, float, float>> waypoints;
        if (nh.getParam(ns + "/waypoints", waypoints_str)) {
            waypoints = parse_waypoints(waypoints_str);
            ROS_INFO("Waypoints loaded from parameter server for %s", ns.c_str());
        } else {
            ROS_ERROR("Failed to get waypoints for %s", ns.c_str());
            return 1;
        }

        ROS_INFO("send points");

        for (auto& wp : waypoints) {
            pose.pose.position.x = std::get<0>(wp);
            pose.pose.position.y = std::get<1>(wp);
            pose.pose.position.z = std::get<2>(wp);

            for (int i = 100; ros::ok() && i > 0; --i) {
                local_pos_pub.publish(pose);
                ros::spinOnce();
                rate.sleep();
            }
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
